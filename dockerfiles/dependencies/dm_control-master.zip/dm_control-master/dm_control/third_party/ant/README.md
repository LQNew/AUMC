# Ant MJCF model

This model is intended for use as a walker in `dm_control.locomotion`. It is
based on Philipp Moritz's original Ant model, which is available from
https://github.com/pcmoritz/mujoco-control-ant. Substantial modifications
have been made to the original model and therefore this model should be regarded
as distinct for practical purposes.
